package com.example.foodiepal.aboutMe

data class AboutMeData(val culinaryJourney: String, val favoriteRecipe: String, val foodPhilosophy: String)
