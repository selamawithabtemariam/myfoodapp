package com.example.foodiepal.contact

data class ContactData(val name: String, val email: String, val phone: String) {
}
